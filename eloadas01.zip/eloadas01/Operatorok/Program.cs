﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operatorok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string argument = "zs";
            Console.WriteLine("Hello");
            if (argument.Length == 1) {
                Console.WriteLine("Egy karakterből áll!!");
            }
            else
            {
                Console.WriteLine("Több mint egy karakter!");
            }

        }
    }
}
