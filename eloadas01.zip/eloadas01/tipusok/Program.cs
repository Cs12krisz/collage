﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tipusok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Primitív típusok
            //Számok
            //Egész
            byte bajt1;//0-255
            bajt1 = 34;
            byte bajt2 = 56;
            byte bajt3;
            sbyte elojelesBajt1;
            elojelesBajt1 = -34;//-128 -- +127
            sbyte elojelesBajt2 = 45;
            short kettoBajtos01 = 32767; //0 - 32767; 2 byte előjeles
            short kettoBajtos02 = -32768;
            ushort kettoBajtos = 65535; // 2 byte előjel nélküli
            int negyBajtos01 = 232433216; // 4 byte előjeles
            int negyBajtos02 = -232433216;
            uint negybajtos03 = 464121221;// 4 byte előjel nélkül
            long nyolcBajtos01 = 21223123213123456; //8 byte előjeles
            long nyolcBajtos02 = -2132112323434323;
            ulong nyolcBajtos03 = 12312432343254435565; // 8 byte előjel nélküli
            //Valós

            float valosF32B01 = 67.45546f; // 4 byte előjeles valós !!!Nincs előjel nélküli valós!!!
            float valosF32B02 = -45.54232f;
            double valos64B01 = 34335.5465456545656546; //4 byte előjeles valós
            decimal valos16B01 = 234234234324234;       //16 byte előjeles valós
            decimal valos16B02 = 234234234324234.6765m;
        }
    }
}

